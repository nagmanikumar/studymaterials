var plus = function(a,b) {
  return console.log(a+b);
};
plus(2,2);