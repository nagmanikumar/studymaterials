var ray = (function() {

  return {
    speak: function() {
      console.log('hello');
    }
  };
})();