(function() {
  console.log('foo');
})();