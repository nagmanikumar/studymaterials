function plus(a, b) {
  var sum = a+b;
  return sum;
}

console.log(plus(2,2));