import {OpaqueToken} from 'angular2/core';

export var lookupLists = {
    mediums: ['Movies', 'Series']
};

export var LOOKUP_LISTS = new OpaqueToken('LookupLists');