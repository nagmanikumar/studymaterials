import {Component} from 'angular2/core';

@Component({
    selector: 'media-item-form',
    templateUrl: 'app/media-item-form.component.html',
    styleUrls: ['app/media-item-form.component.css']
})
export class MediaItemFormComponent {
    onSubmit(mediaItem) {
        console.log(mediaItem);
    }
}