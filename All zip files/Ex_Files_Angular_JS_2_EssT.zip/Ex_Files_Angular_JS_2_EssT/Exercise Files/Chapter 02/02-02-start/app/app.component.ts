import {Component} from 'angular2/core';

@Component({
    selector: 'app',
    template: '<h1>My App</h1>'
})
export class AppComponent {}