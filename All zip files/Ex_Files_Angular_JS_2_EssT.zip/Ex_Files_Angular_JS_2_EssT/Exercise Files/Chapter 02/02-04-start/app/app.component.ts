import {Component} from 'angular2/core';

@Component({
    selector: 'media-tracker-app',
    templateUrl: 'app/app.component.html'
})
export class AppComponent {}