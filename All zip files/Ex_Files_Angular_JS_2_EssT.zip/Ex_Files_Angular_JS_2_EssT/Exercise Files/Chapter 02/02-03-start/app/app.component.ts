import {Component} from 'angular2/core';

@Component({
    selector: 'media-tracker-app',
    template: '<h1>My App</h1>'
})
export class AppComponent {}