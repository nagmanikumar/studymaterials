import {Component} from 'angular2/core';

@Component({
    selector: 'media-tracker-app',
    templateUrl: 'app/app.component.html',
    styleUrls: ['app/app.component.css']
})
export class AppComponent {}